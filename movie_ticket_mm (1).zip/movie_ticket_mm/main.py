import pymongo
from flask import Flask, request, render_template , session, redirect
import os
import datetime

from Mail import send_email

APP_ROOT = os.path.dirname(os.path.abspath(__file__))

from bson import ObjectId
app = Flask(__name__)
app.secret_key = "movie_ticket"
my_client = pymongo.MongoClient('mongodb://localhost:27017')
my_db = my_client["Movie_Ticket"]
admin_col = my_db['admin']
customer_col = my_db['customer']
language_col = my_db['language']
movies_col = my_db['movies']
schedule_col = my_db['schedule']
theatre_col = my_db['theatre']
booking_col = my_db["bookings"]
payment_col = my_db["Payments"]
ticket_col = my_db["tickets"]
count = admin_col.count_documents({})
if count == 0:
    admin = {"Admin_Email": "admin@gmail.com", "Admin_Password": "admin"}
    admin_col.insert_one(admin)

@app.route("/")
def index():
    query = {'dates.2023-06-23': '1:33', 'theatre_id': ObjectId('64914f5d1250f249eaf3f3ec'), 'screen_name': 'Screen 0'}
    schedule = schedule_col.find_one(query)
    print(schedule)
    return render_template("index.html")

@app.route("/adminlog")
def adminlog():
    return render_template("adminlog.html")

@app.route("/adminlog1", methods = ['post'])
def adminlog1():
    Admin_Email = request.form.get("Admin_Email")
    Admin_Password = request.form.get("Admin_Password")
    query = {"Admin_Email": Admin_Email , "Admin_Password": Admin_Password}
    admin = admin_col.find_one(query)
    if admin != None:
        session['admin_id'] = str(admin['_id'])
        session['role'] = 'Admin'
        return redirect("admin_home")
    else:
        return render_template("message.html" , message="Fail to Log")

@app.route("/admin_home")
def admin_home():
    return render_template("admin_home.html")

@app.route("/customerlog")
def customerlog():
    return render_template("customerlog.html")

@app.route("/customerlog1", methods = ['post'])
def customerlog1():
    customer_email = request.form.get("customer_email")
    customer_password = request.form.get("customer_password")
    query = {"customer_email": customer_email, "customer_password": customer_password}
    customer = customer_col.find_one(query)
    if customer != None:
        session['customer_id'] = str(customer['_id'])
        session['role'] = 'customer'
        return redirect("customer_home")
    else:
        return render_template("message.html", message="Fail to Log")

@app.route("/customerreg")
def customerreg():
    return render_template("customerreg.html")

@app.route("/customerreg1" , methods = ['post'])
def customerreg1():
    customer_name = request.form.get("customer_name")
    customer_email = request.form.get("customer_email")
    customer_phone = request.form.get("customer_phone")
    customer_password = request.form.get("customer_password")
    customer_address = request.form.get("customer_address")
    gender = request.form.get("gender")
    query = {"customer_email": customer_email, "customer_phone": customer_phone}
    count = customer_col.count_documents(query)
    if count == 0:
        query1 = {"customer_name": customer_name, "customer_email": customer_email, "customer_phone": customer_phone,"customer_password": customer_password, "customer_address": customer_address, "gender": gender,}
        customer_col.insert_one(query1)
        return render_template("message.html", message="Customer Registered Successfull")
    else:
        return render_template("message.html", message="Fail to Register")

@app.route("/add_view_language")
def add_view_language():
    languages = language_col.find()
    return render_template("add_view_language.html",languages=languages)

@app.route("/add_view_language1", methods = ['post'])
def add_view_language1():
    language_name = request.form.get("language_name")
    query = {"language_name": language_name}
    count = language_col.count_documents(query)
    if count == 0:
        query1 = {"language_name": language_name}
        language_col.insert_one(query1)
        return redirect("/add_view_language")
    else:
        return render_template("message.html", message="Fail to Add")

@app.route("/add_movies")
def add_movies():
    moviess = movies_col.find()
    return render_template("add_movies.html",moviess=moviess)

@app.route("/add_movies1", methods = ['post'])
def add_movies1():
    movie_name = request.form.get("movie_name")
    release_date = request.form.get("release_date")
    movie_joner = request.form.get("movie_joner")
    certificate_type = request.form.get("certificate_type")
    poster = request.files.get('poster')
    path = APP_ROOT + "/static/myfiles/" + poster.filename
    poster.save(path)
    description = request.form.get("description")
    query = {"movie_name": movie_name}
    count = movies_col.count_documents(query)
    if count == 0:
        query1 = {"movie_name": movie_name,"release_date": release_date,"movie_joner": movie_joner,"certificate_type": certificate_type,"poster": poster.filename,"description": description}
        movies_col.insert_one(query1)
        return redirect("/add_movies")
    else:
        return render_template("message.html", message="Fail to Add")

@app.route("/add_theatre")
def add_theatre():
    theatres = theatre_col.find()
    return render_template("add_theatre.html",theatres=theatres,formate_time=formate_time)

@app.route("/add_theatre1", methods = ['post'])
def add_theatre1():
    theatre_name = request.form.get("theatre_name")
    no_of_screens = request.form.get("no_of_screens")
    address = request.form.get("address")
    theatre_picture = request.files.get('theatre_picture')
    path = APP_ROOT + "/static/myfiles/" + theatre_picture.filename
    theatre_picture.save(path)
    screens = []
    for i in range(int(no_of_screens)) :
        screen = {"screen_name": request.form.get("screen_name"+str(i)),
                   "show_time": [request.form.get("show1"+str(i)),
                                 request.form.get("show2"+str(i)),
                                 request.form.get("show3"+str(i)),
                                 request.form.get("show4"+str(i))],
                   "no_of_seats": request.form.get("no_of_seats"+str(i))}
        screens.append(screen)
    query = {"theatre_name": theatre_name}
    count = theatre_col.count_documents(query)
    if count == 0:
        query1 = {"theatre_name": theatre_name,"no_of_screens": no_of_screens,"address": address,"theatre_picture": theatre_picture.filename, "screens": screens}
        theatre_col.insert_one(query1)
        return redirect("/add_theatre")
    else:
        return render_template("message.html", message="Fail to Add")

def formate_time(time):
    date = datetime.datetime.strptime(str(datetime.datetime.now().date())+" "+time,"%Y-%m-%d %H:%M")
    time = str(date.strftime("%I"))+":"+str(date.strftime("%M"))+" "+str(date.strftime("%p"))
    return time

@app.route("/add_schedule")
def add_schedule():
    languages = language_col.find()
    moviess = movies_col.find()
    theatres = theatre_col.find()
    return render_template("add_schedule.html",languages=languages,moviess=moviess,theatres=theatres)

@app.route("/get_screens")
def get_screens():
    theatre_id = request.args.get("theatre_id")
    query ={"_id": ObjectId(theatre_id)}
    theatre = theatre_col.find_one(query)
    return render_template("get_screens.html", screens=theatre['screens'])

@app.route("/get_shows")
def get_shows():
    theatre_id = request.args.get("theatre_id")
    screen_name = request.args.get("screen_name")
    query = {"_id": ObjectId(theatre_id)}
    theatre = theatre_col.find_one(query)
    for screen in theatre['screens']:
        if screen['screen_name'] == screen_name:
            shows = screen['show_time']
    return render_template("get_shows.html", shows=shows)


@app.route("/add_schedule1", methods =['post'])
def add_schedule1():
    language_id = request.form.get("language_id")
    movies_id = request.form.get("movies_id")
    theatre_id = request.form.get("theatre_id")
    screen_name = request.form.get("screen_name")
    ticket_price = request.form.get("ticket_price")
    movie_type = request.form.get("movie_type")
    from_date = request.form.get("from_date")
    to_date = request.form.get("to_date")
    from_date = datetime.datetime.strptime(from_date, '%Y-%m-%d')
    to_date = datetime.datetime.strptime(to_date, '%Y-%m-%d')
    number_days = request.form.get("number_days")
    dates = []
    for i in range(int(number_days)):
        date = request.form.get("show_date"+ str(i))
        shows = request.form.getlist("shows" + str(i))
        dates.append({date:shows})
        for show in shows:
            query = {"dates."+str(date): show,"theatre_id": ObjectId(theatre_id),"screen_name": screen_name}
            print(query)
            count = schedule_col.count_documents(query)
            if count > 0:
                return render_template("message.html", message="There is time conflict to add the schedule for this screen")
    query = {"_id": ObjectId(movies_id)}
    movies = movies_col.find_one(query)
    query = {"language_id": ObjectId(language_id),"movies_id": ObjectId(movies_id),"theatre_id": ObjectId(theatre_id),"screen_name": screen_name,"ticket_price": ticket_price,"movie_type": movies['movie_joner'],"dates": dates,"from_date":from_date,"to_date":to_date}
    schedule_col.insert_one(query)
    return render_template("message.html", message="Schedule Added")

@app.route("/view_schedule")
def view_schedule():
    schedules = schedule_col.find()
    return render_template("view_schedule.html",get_screen_name_by_schedule=get_screen_name_by_schedule,formate_time=formate_time,schedules=schedules,get_language=get_language,get_movie=get_movie,get_theatre=get_theatre)

def get_screen_name_by_schedule(theatre_id):
    theater = theatre_col.find_one({"_id":ObjectId(theatre_id)})
    screen_name = []
    for screen_names in theater['screens']:
        screen_name.append({"screen_name":screen_names['screen_name']})
    print(screen_name)
    return screen_name



def get_language(language_id):
    query = {"_id": ObjectId(language_id)}
    language = language_col.find_one(query)
    return language

def get_movie(movies_id):
    query = {"_id": ObjectId(movies_id)}
    movie = movies_col.find_one(query)
    return movie

def get_theatre(theatre_id):
    query = {"_id": ObjectId(theatre_id)}
    theatre = theatre_col.find_one(query)
    return theatre

@app.route("/customer_home")
def customer_home():
    return render_template("customer_home.html")

@app.route("/customer_view_movies")
def customer_view_movies():
    booking_date = request.args.get("booking_date")
    if booking_date == None:
        booking_date = datetime.datetime.now()
    else:
        booking_date = datetime.datetime.strptime(booking_date, '%Y-%m-%d')
    query = {"from_date": {"$lte": booking_date},"to_date": {"$gte": booking_date }}
    schedules = schedule_col.find(query)
    movie_ids = []
    for schedule in schedules:
        movie_ids.append({"_id": schedule['movies_id']})
    booking_date = booking_date.strftime('%Y-%m-%d')
    if len(movie_ids) > 0:
        query = {"$or": movie_ids}
        moviess = movies_col.find(query)
        message = "Movies Available on "+str(booking_date)
    else:
        moviess = []
        message = "Movies not available on " + str(booking_date)
    return render_template("customer_view_movies.html",moviess=moviess,booking_date=str(booking_date),message=message)

@app.route("/book")
def book():
    movies_id = request.args.get("movies_id")
    booking_date = request.args.get("booking_date")
    booking_date2 = booking_date
    booking_date = datetime.datetime.strptime(booking_date, '%Y-%m-%d')
    query = {"from_date": {"$lte": booking_date},"to_date": {"$gte": booking_date },"movies_id": ObjectId(movies_id)}
    schedules = schedule_col.find(query)
    theatre_ids = []
    for schedule in schedules:
        theatre_ids.append({"_id": schedule['theatre_id']})
    query = {"$or": theatre_ids }
    theatres = theatre_col.find(query)
    return render_template("book.html",theatres=theatres,movies_id=movies_id,booking_date=booking_date,booking_date2=booking_date2,get_schedule=get_schedule,formate_time=formate_time)

def get_schedule(movies_id,booking_date,theatre_id):
    query = {"from_date": {"$lte": booking_date}, "to_date": {"$gte": booking_date}, "movies_id": ObjectId(movies_id), "theatre_id": ObjectId(theatre_id)}
    schedule = schedule_col.find_one(query)
    return schedule

@app.route("/logout")
def logout():
    session.clear()
    return render_template("index.html")



def formate_time(time):
    date = datetime.datetime.strptime(str(datetime.datetime.now().date())+" "+time,"%Y-%m-%d %H:%M")
    time = str(date.strftime("%I"))+":"+str(date.strftime("%M"))+" "+str(date.strftime("%p"))
    return time


@app.route("/view_seats_layout")
def view_seats_layout():
    no_of_seats = request.args.get("no_of_seats")
    screen_name = request.args.get("screen_name")
    booking_date = request.args.get("booking_date")
    show_time = request.args.get("show_time")
    movies_id = request.args.get("movies_id")

    schedule_id = request.args.get("schedule_id")

    schedule = schedule_col.find_one({"_id":ObjectId(schedule_id)})
    return render_template("view_seats_layout.html",int=int,isSeatBooked=isSeatBooked,str=str,screen_name=screen_name,schedule=schedule,booking_date=booking_date,show_time=show_time,schedule_id=schedule_id,get_theater_by_schedule_id=get_theater_by_schedule_id)


def get_theater_by_schedule_id(theatre_id):
    print(theatre_id)
    theatre = theatre_col.find_one({"_id":ObjectId(theatre_id)})
    return theatre


@app.route("/book_tickets",methods=['post'])
def book_tickets():
    booking_date = request.form.get("booking_date")
    show_time = request.form.get("show_time")
    schedule_id = request.form.get("schedule_id")
    schedule = schedule_col.find_one({"_id":ObjectId(schedule_id)})
    schedule2 = schedule_col.find_one({"_id": ObjectId(schedule_id)})
    theatre_id = schedule['theatre_id']
    theatre = theatre_col.find_one({"_id":ObjectId(theatre_id)})
    theatre2 = theatre_col.find_one({"_id": ObjectId(theatre_id)})
    screen_name = request.form.get("screen_name")
    seat_numbers = []
    totalPrice = 0
    for screen_names in theatre['screens']:
        if screen_names['screen_name'] == screen_name :
            for i in range(int(screen_names['no_of_seats'])+1):
                seat = request.form.get(str(schedule_id) + "seat" + str(i))
                if seat == 'on':
                    seatDetails = {"seat": str(i)}
                    seat_numbers.append(seatDetails)
                    totalPrice = totalPrice + int(schedule['ticket_price'])

    query = {"schedule_id": ObjectId(schedule_id),"screen_name":screen_name, "seat_numbers": seat_numbers, "booking_date": booking_date, "show_time":show_time,"date":datetime.datetime.now(),"status":'Payment Pending',"customer_id":ObjectId(session['customer_id']),"totalPrice":totalPrice}
    result = booking_col.insert_one(query)
    booking_id = result.inserted_id
    return render_template("book_tickets.html",theatre_id=theatre_id,screen_name=screen_name,theatre=theatre2,schedule=schedule2,get_movie_by_scheduleId=get_movie_by_scheduleId,booking_id=booking_id,totalPrice=totalPrice,seat_numbers=seat_numbers,booking_date=booking_date,show_time=show_time,schedule_id=schedule_id)


def get_movie_by_scheduleId(movies_id):
    movie = movies_col.find_one({"_id":ObjectId(movies_id)})
    return movie


@app.route("/book_tickets1",methods=['post'])
def book_tickets1():
    schedule_id = request.form.get("schedule_id")
    theatre_id = request.form.get("theatre_id")
    booking_id = request.form.get("booking_id")
    totalPrice = request.form.get("totalPrice")
    return render_template("pay_amount.html",booking_id=booking_id,totalPrice=totalPrice,theatre_id=theatre_id,schedule_id=schedule_id)

@app.route("/pay_amount1",methods=['post'])
def pay_amount1():
    schedule_id = request.form.get("schedule_id")
    schedule = schedule_col.find_one({"_id":ObjectId(schedule_id)})
    language_id = schedule['language_id']
    theatre_id = schedule['theatre_id']
    theatre = theatre_col.find_one({"_id":ObjectId(theatre_id)})
    language = language_col.find_one({"_id":ObjectId(language_id)})
    movies_id = schedule['movies_id']
    movie = movies_col.find_one({"_id":ObjectId(movies_id)})
    booking_id = request.form.get("booking_id")
    cardNumber = request.form.get("cardNumber")
    nameOnCard = request.form.get("nameOnCard")
    totalPrice = request.form.get('totalPrice')
    query = {"$set":{"status":'Movie Tickets Booked'}}
    booking_col.update_one({"_id":ObjectId(booking_id)},query)
    payment_col.insert_one({"booking_id":ObjectId(booking_id),"cardNumber":cardNumber,"card_holder_name":nameOnCard,"date":datetime.datetime.now(),"amount":totalPrice,"customer_id":ObjectId(session['customer_id'])})
    booking = booking_col.find_one({"_id":ObjectId(booking_id)})
    seat_numbers = booking['seat_numbers']
    screen_name = booking['screen_name']
    booking_date = booking['booking_date']
    show_time = booking['show_time']
    booking = booking_col.find_one({"_id":ObjectId(booking_id)})
    customer = customer_col.find_one({'_id':ObjectId(session['customer_id'])})
    email = customer['customer_email']
    print(email)
    booked_date = str(datetime.datetime.now())
    for seat_number in seat_numbers:
        ticket_col.insert_one({"show_time":show_time,"screen_name":screen_name,"seat_number":seat_number['seat'],"booking_date":booking_date,"booking_id":ObjectId(booking_id),"totalPrice":totalPrice})
    tickets_str = ""
    for ticket in booking['seat_numbers']:
        tickets_str = tickets_str + str(ticket['seat']) + " \t"
    print(tickets_str)
    send_email("Movie Ticket Booking Confirmed", " \n  Movie Name: "+movie['movie_name']+" ("+language['language_name']+") \n Theater Name : "+theatre['theatre_name']+", "+theatre['address']+" \n Screen : "+screen_name+" \n  Show Time: "+show_time+" \n  Booking Date : "+booking_date+" \n  SeatNumbers : "+str(tickets_str)+" \n Booking Time : "+booked_date+"", email)
    return render_template("message.html",message="Movie Booked Successfully",color='text-success')


def isSeatBooked(schedule_id,i,booking_date,show_time):
    query = {"schedule_id":ObjectId(schedule_id),"booking_date":booking_date,"show_time":show_time,"status":'Movie Tickets Booked'}
    bookings = booking_col.find(query)
    for booking in bookings:
        for ticket in booking['seat_numbers']:
            if(str(ticket['seat'])) == str(i):
                return True
    return False


@app.route("/viewBookings")
def viewBookings():
    query = {}
    if session['role'] == 'Admin':
        schedule_id = request.args.get("schedule_id")
        booking_date = request.args.get("booking_date")
        show_time = request.args.get("show_time")
        query = {"schedule_id": ObjectId(schedule_id), "booking_date":booking_date,"show_time":show_time}
    if session['role'] == 'customer':
        query = {"customer_id":ObjectId(session['customer_id']),"status":'Movie Tickets Booked'}
    bookings = booking_col.find(query)
    bookings = list(bookings)
    if len(bookings) == 0:
        return render_template("message.html", msg='No Bookings')
    return render_template("viewBookings.html",get_time_gap_to_cancel_ticket=get_time_gap_to_cancel_ticket,get_language_by_scheduled_booking_id=get_language_by_scheduled_booking_id,len=len,get_customer_by_bookings=get_customer_by_bookings,get_theater_by_scheduled_booking_id=get_theater_by_scheduled_booking_id,formate_time=formate_time,get_movie_id_by_scheduled_bookings=get_movie_id_by_scheduled_bookings,bookings=bookings,get_schedule_by_bookingId=get_schedule_by_bookingId)


def get_schedule_by_bookingId(schedule_id):
    schedule = schedule_col.find_one({"_id":ObjectId(schedule_id)})
    return schedule

def get_schedule_by_bookingId1(schedule_id):
    schedule = schedule_col.find_one({"_id":ObjectId(schedule_id)})
    return schedule

def get_movie_id_by_scheduled_bookings(movies_id):
    movie = movies_col.find_one({"_id":ObjectId(movies_id)})
    return movie

def get_movie_id_by_scheduled_bookings1(movies_id):
    movie = movies_col.find_one({"_id":ObjectId(movies_id)})
    return movie

def get_theater_by_scheduled_booking_id(theatre_id):
    theater = theatre_col.find_one({"_id":ObjectId(theatre_id)})
    return theater

def get_customer_by_bookings(customer_id):
    customer = customer_col.find_one({"_id":ObjectId(customer_id)})
    return customer


def get_language_by_scheduled_booking_id(language_id):
    language = language_col.find_one({"_id":ObjectId(language_id)})
    return language

@app.route("/view_tickets")
def view_tickets():
    booking_id = request.args.get("booking_id")
    tickets = ticket_col.find({'booking_id':ObjectId(booking_id)})
    return render_template("view_tickets.html",get_booking_by_ticket=get_booking_by_ticket,get_language_by_scheduled_booking_id1=get_language_by_scheduled_booking_id1,len=len,get_customer_by_bookings1=get_customer_by_bookings1,get_theater_by_scheduled_booking_id1=get_theater_by_scheduled_booking_id1,formate_time=formate_time,get_movie_id_by_scheduled_bookings1=get_movie_id_by_scheduled_bookings1,tickets=tickets,get_schedule_by_bookingId1=get_schedule_by_bookingId1)

def get_language_by_scheduled_booking_id1(language_id):
    language = language_col.find_one({"_id":ObjectId(language_id)})
    return language


def get_customer_by_bookings1(customer_id):
    customer = customer_col.find_one({"_id":ObjectId(customer_id)})
    return customer


def get_theater_by_scheduled_booking_id1(theatre_id):
    theater = theatre_col.find_one({"_id":ObjectId(theatre_id)})
    return theater

def get_booking_by_ticket(booking_id):
    booking = booking_col.find_one({"_id":ObjectId(booking_id)})
    return booking


def get_time_gap_to_cancel_ticket(booking):
    booked_show = datetime.datetime.strptime(str(booking['booking_date'])+" "+str(booking['show_time']), "%Y-%m-%d %H:%M")
    today = datetime.datetime.now()
    if booked_show <= today:
        print('ffff')
        return -1
    diff = booked_show - today
    days, seconds = diff.days, diff.seconds
    hours = days * 24 + seconds // 3600
    minutes = (seconds % 3600) // 60
    seconds = seconds % 60
    print(hours, minutes, seconds)
    return hours

@app.route("/cancel_booking",methods=['post'])
def cancel_booking():
    booking_id = request.form.get('booking_id')
    query = {"$set":{"status":'Booking Cancelled'}}
    booking_col.update_one({"_id":ObjectId(booking_id)},query)
    return render_template("message.html",message="Booking Cancelled",color='text-danger')


@app.route("/cancelledBookings")
def cancelledBookings():
    query = {}
    if session['role'] == 'customer':
        query = {"customer_id": ObjectId(session['customer_id']),"status":'Booking Cancelled'}
    bookings = booking_col.find(query)
    bookings = list(bookings)
    if len(bookings) == 0:
        return render_template("message.html",msg='No Cancelled Bookings')
    return render_template("cancelledBookings.html",get_time_gap_to_cancel_ticket=get_time_gap_to_cancel_ticket,get_language_by_scheduled_booking_id=get_language_by_scheduled_booking_id,len=len,get_customer_by_bookings=get_customer_by_bookings,get_theater_by_scheduled_booking_id=get_theater_by_scheduled_booking_id,formate_time=formate_time,get_movie_id_by_scheduled_bookings=get_movie_id_by_scheduled_bookings,bookings=bookings,get_schedule_by_bookingId=get_schedule_by_bookingId)






app.run(debug=True)